#include "cEditor.h"
#include <Engine/Math/Constants.h>




eae6320::cResult cEditor::LoadAsset(const char* const i_path)
{
	auto result = eae6320::Results::Success;

	// Create a new Lua state
	lua_State* luaState = nullptr;
	eae6320::cScopeGuard scopeGuard_onExit([&luaState]
		{
			if (luaState)
			{
				// If I haven't made any mistakes
				// there shouldn't be anything on the stack
				// regardless of any errors
				EAE6320_ASSERT(lua_gettop(luaState) == 0);

				lua_close(luaState);
				luaState = nullptr;
			}
		});
	{
		luaState = luaL_newstate();
		if (!luaState)
		{
			result = eae6320::Results::OutOfMemory;
			std::cerr << "Failed to create a new Lua state" << std::endl;
			return result;
		}
	}

	// Load the asset file as a "chunk",
	// meaning there will be a callable function at the top of the stack
	const auto stackTopBeforeLoad = lua_gettop(luaState);
	{
		const auto luaResult = luaL_loadfile(luaState, i_path);
		if (luaResult != LUA_OK)
		{
			result = eae6320::Results::Failure;
			std::cerr << lua_tostring(luaState, -1) << std::endl;
			// Pop the error message
			lua_pop(luaState, 1);
			return result;
		}
	}
	// Execute the "chunk", which should load the asset
	// into a table at the top of the stack
	{
		constexpr int argumentCount = 0;
		constexpr int returnValueCount = LUA_MULTRET;	// Return _everything_ that the file returns
		constexpr int noMessageHandler = 0;
		const auto luaResult = lua_pcall(luaState, argumentCount, returnValueCount, noMessageHandler);
		if (luaResult == LUA_OK)
		{
			// A well-behaved asset file will only return a single value
			const auto returnedValueCount = lua_gettop(luaState) - stackTopBeforeLoad;
			if (returnedValueCount == 1)
			{
				// A correct asset file _must_ return a table
				if (!lua_istable(luaState, -1))
				{
					result = eae6320::Results::InvalidFile;
					std::cerr << "Asset files must return a table (instead of a "
						<< luaL_typename(luaState, -1) << ")" << std::endl;
					// Pop the returned non-table value
					lua_pop(luaState, 1);
					return result;
				}
			}
			else
			{
				result = eae6320::Results::InvalidFile;
				std::cerr << "Asset files must return a single table (instead of "
					<< returnedValueCount << " values)" << std::endl;
				// Pop every value that was returned
				lua_pop(luaState, returnedValueCount);
				return result;
			}
		}
		else
		{
			result = eae6320::Results::InvalidFile;
			std::cerr << lua_tostring(luaState, -1);
			// Pop the error message
			lua_pop(luaState, 1);
			return result;
		}
	}

	// If this code is reached the asset file was loaded successfully,
	// and its table is now at index -1

	// A scope guard is used to pop the asset as soon as the scope (this function) is left
	eae6320::cScopeGuard scopeGuard_popAssetTable([luaState]
		{
			lua_pop(luaState, 1);
		});

	// Load the values, assuming that the asset table is at index -1
	result = LoadTableValues(*luaState);

	return result;
}

eae6320::cResult cEditor::LoadTableValues_scale(lua_State& io_luaState)
{
	auto result = eae6320::Results::Success;

	// Right now the asset table is at -1.
	// After the following table operation it will be at -2
	// and the "parameters" table will be at -1:
	constexpr auto* const key = "scale";
	lua_pushstring(&io_luaState, key);
	lua_gettable(&io_luaState, -2);
	eae6320::cScopeGuard scopeGuard_popParameters([&io_luaState]
		{
			lua_pop(&io_luaState, 1);
		});
	if (lua_istable(&io_luaState, -1))
	{
		if (!(result = LoadTableValues_scale_values(io_luaState)))
		{
			return result;
		}
	}
	else
	{
		result = eae6320::Results::InvalidFile;
		std::cerr << "The value at \"" << key << "\" must be a table "
			"(instead of a " << luaL_typename(&io_luaState, -1) << ")" << std::endl;
		return result;
	}

	return result;
}

eae6320::cResult cEditor::LoadTableValues_scale_values(lua_State& io_luaState)
{
	// Right now the parameters table is at -1.
		// Every time the while() statement is executed it will be at -2
		// and the next key will be at -1.
		// Inside the block the table will be at -3,
		// the current key will be at -2,
		// and the value will be at -1.
		// (You may want to review LoadTableValues_allKeys()
		// in the ReadTopLevelTableValues example,
		// but remember that you don't need to know how to do this technique)

	auto result = eae6320::Results::Success;

	std::cout << "Iterating through the parameters:" << std::endl;
	int starter = 0;
	lua_pushnil(&io_luaState);
	while (lua_next(&io_luaState, -2))
	{
		std::string myString = lua_tostring(&io_luaState, -2);
		if (myString == "X")
			scale["X"] = static_cast<float>(lua_tonumber(&io_luaState, -1));
		else if (myString == "Y")
			scale["Y"] = static_cast<float>(lua_tonumber(&io_luaState, -1));
		else if (myString == "Z")
			scale["Z"] = static_cast<float>(lua_tonumber(&io_luaState, -1));
		lua_pop(&io_luaState, 1);
		starter++;
	}

	return result;
}


eae6320::cResult cEditor::LoadTableValues_location(lua_State& io_luaState)
{
	auto result = eae6320::Results::Success;

	// Right now the asset table is at -1.
	// After the following table operation it will be at -2
	// and the "parameters" table will be at -1:
	constexpr auto* const key = "location";
	lua_pushstring(&io_luaState, key);
	lua_gettable(&io_luaState, -2);
	eae6320::cScopeGuard scopeGuard_popParameters([&io_luaState]
		{
			lua_pop(&io_luaState, 1);
		});
	if (lua_istable(&io_luaState, -1))
	{
		if (!(result = LoadTableValues_location_values(io_luaState)))
		{
			return result;
		}
	}
	else
	{
		result = eae6320::Results::InvalidFile;
		std::cerr << "The value at \"" << key << "\" must be a table "
			"(instead of a " << luaL_typename(&io_luaState, -1) << ")" << std::endl;
		return result;
	}

	return result;
}

eae6320::cResult cEditor::LoadTableValues_location_values(lua_State& io_luaState)
{
	// Right now the parameters table is at -1.
		// Every time the while() statement is executed it will be at -2
		// and the next key will be at -1.
		// Inside the block the table will be at -3,
		// the current key will be at -2,
		// and the value will be at -1.
		// (You may want to review LoadTableValues_allKeys()
		// in the ReadTopLevelTableValues example,
		// but remember that you don't need to know how to do this technique)

	auto result = eae6320::Results::Success;

	std::cout << "Iterating through the parameters:" << std::endl;
	int starter = 0;
	lua_pushnil(&io_luaState);
	while (lua_next(&io_luaState, -2))
	{
		std::string myString = lua_tostring(&io_luaState, -2);
		if (myString == "X")
			location["X"] = static_cast<float>(lua_tonumber(&io_luaState, -1));
		else if (myString == "Y")
			location["Y"] = static_cast<float>(lua_tonumber(&io_luaState, -1));
		else if (myString == "Z")
			location["Z"] = static_cast<float>(lua_tonumber(&io_luaState, -1));
		lua_pop(&io_luaState, 1);
		starter++;
	}

	return result;
}


eae6320::cResult cEditor::LoadTableValues_rotation(lua_State& io_luaState)
{
	auto result = eae6320::Results::Success;

	// Right now the asset table is at -1.
	// After the following table operation it will be at -2
	// and the "parameters" table will be at -1:
	constexpr auto* const key = "rotation";
	lua_pushstring(&io_luaState, key);
	lua_gettable(&io_luaState, -2);
	eae6320::cScopeGuard scopeGuard_popParameters([&io_luaState]
		{
			lua_pop(&io_luaState, 1);
		});
	if (lua_istable(&io_luaState, -1))
	{
		if (!(result = LoadTableValues_rotation_values(io_luaState)))
		{
			return result;
		}
	}
	else
	{
		result = eae6320::Results::InvalidFile;
		std::cerr << "The value at \"" << key << "\" must be a table "
			"(instead of a " << luaL_typename(&io_luaState, -1) << ")" << std::endl;
		return result;
	}

	return result;
}

eae6320::cResult cEditor::LoadTableValues_rotation_values(lua_State& io_luaState)
{
	// Right now the parameters table is at -1.
		// Every time the while() statement is executed it will be at -2
		// and the next key will be at -1.
		// Inside the block the table will be at -3,
		// the current key will be at -2,
		// and the value will be at -1.
		// (You may want to review LoadTableValues_allKeys()
		// in the ReadTopLevelTableValues example,
		// but remember that you don't need to know how to do this technique)

	auto result = eae6320::Results::Success;

	std::cout << "Iterating through the parameters:" << std::endl;
	int starter = 0;
	lua_pushnil(&io_luaState);
	while (lua_next(&io_luaState, -2))
	{
		std::string myString = lua_tostring(&io_luaState, -2);
		if (myString == "X")
			rotation["X"] = static_cast<float>(lua_tonumber(&io_luaState, -1));
		else if (myString == "Y")
			rotation["Y"] = static_cast<float>(lua_tonumber(&io_luaState, -1));
		else if (myString == "Z")
			rotation["Z"] = static_cast<float>(lua_tonumber(&io_luaState, -1));
		lua_pop(&io_luaState, 1);
		starter++;
	}

	return result;
}


eae6320::cResult cEditor::LoadTableValues(lua_State& io_luaState)
{
	auto result = eae6320::Results::Success;

	if (!(result = LoadTableValues_scale(io_luaState)))
	{
		return result;
	}
	if (!(result = LoadTableValues_location(io_luaState)))
	{
		return result;
	}
	if (!(result = LoadTableValues_rotation(io_luaState)))
	{
		return result;
	}
	return result;
}

eae6320::Math::cMatrix_transformation cEditor::createFullTransformMatrix()
{
	// Translate Rotate Scale


	// Translate
	eae6320::Math::cMatrix_transformation transformMatrix = eae6320::Math::cMatrix_transformation::CreateTranslationMetrix(location["X"], location["Y"], location["Z"]);

	// Rotate
	float angleFactor = eae6320::Math::g_pi / 180.0f;
	eae6320::Math::cMatrix_transformation rotateXMatrix = eae6320::Math::cMatrix_transformation::CreateXRotationMatrix(rotation["X"] * angleFactor);
	eae6320::Math::cMatrix_transformation rotateYMatrix = eae6320::Math::cMatrix_transformation::CreateYRotationMatrix(rotation["Y"] * angleFactor);
	eae6320::Math::cMatrix_transformation rotateZMatrix = eae6320::Math::cMatrix_transformation::CreateZRotationMatrix(rotation["Z"] * angleFactor);

	// Scale
	eae6320::Math::cMatrix_transformation scaleMatrix = eae6320::Math::cMatrix_transformation::CreateScaleMetrix(scale["X"], scale["Y"], scale["Z"]);
	return transformMatrix * rotateXMatrix * rotateYMatrix * rotateZMatrix * scaleMatrix;
}

eae6320::cResult cEditor::ReadEditorTableValues(const std::string& editorFilePath)
{
	// The LoadAsset() function does _exactly_ what was shown
// in the LoadTableFromFile examples.
// After the table is loaded at the top of the stack, though,
// LoadTableValues() is called,
// so that is the function you should pay attention to.

	auto result = eae6320::Results::Success;
	//constexpr auto* const path = editorFilePath.c_str();
	const auto* const path = editorFilePath.c_str();
	if (!(result = LoadAsset(path)))
	{
		return result;
	}

	return result;
}
