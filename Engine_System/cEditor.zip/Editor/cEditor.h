#pragma once
#include <Engine/Results/cResult.h>
#include <External/Lua/Includes.h>
#include <string>
#include <Engine/ScopeGuard/cScopeGuard.h>
#include <Engine/Results/Results.h>
#include <Engine/Math/cMatrix_transformation.h>
#include <Engine/Asserts/Asserts.h>
#include <iostream>
#include <map>
#include <Engine/GameObject/cGameObject.h>

class cEditor
{

public: 

	eae6320::cResult ReadEditorTableValues(const std::string& editorFilePath);
	eae6320::Math::cMatrix_transformation createFullTransformMatrix();

private:
	std::map<std::string, float> scale;
	std::map<std::string, float> location;
	std::map<std::string, float> rotation;




	eae6320::cResult LoadAsset(const char* const i_path);
	eae6320::cResult LoadTableValues_scale(lua_State& io_luaState);
	eae6320::cResult LoadTableValues_scale_values(lua_State& io_luaState);

	eae6320::cResult LoadTableValues_location(lua_State& io_luaState);
	eae6320::cResult LoadTableValues_location_values(lua_State& io_luaState);

	eae6320::cResult LoadTableValues_rotation(lua_State& io_luaState);
	eae6320::cResult LoadTableValues_rotation_values(lua_State& io_luaState);


	eae6320::cResult LoadTableValues(lua_State& io_luaState);


};

