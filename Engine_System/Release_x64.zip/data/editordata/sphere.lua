return
{
	location = {
		X = 2.0,
		Y = 0.0,
		Z = 0.0,
	},
	
	scale = { 
		X = 3.0,
		Y = 1.0,
		Z = 1.0,
	},
	
	rotation = {
		X = 0.0,
		Y = 0.0,
		Z = 0.0,
	},
}