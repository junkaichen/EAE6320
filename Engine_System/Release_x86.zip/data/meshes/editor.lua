return
{
	scale = { 
		X = 3.0,
		Y = 1.0,
		Z = 1.0,
	},

	parameters =
	{
		g_brightness = 12.3,
		g_speed = 4.56,	
	},
}
