return
{
	location = {
		X = 4.0,
		Y = 4.5,
		Z = 0.0,
	},
	
	scale = { 
		X = 1.0,
		Y = 1.0,
		Z = 1.0,
	},
	
	rotation = {
		X = 0.0,
		Y = 0.0,
		Z = 0.0,
	},
}