return
{
	location = {
		X = -2.0,
		Y = 0.0,
		Z = 0.0,
	},
	
	scale = { 
		X = 0.07,
		Y = 0.07,
		Z = 0.07,
	},
	
	rotation = {
		X = 0.0,
		Y = -90.0,
		Z = 0.0,
	},
}